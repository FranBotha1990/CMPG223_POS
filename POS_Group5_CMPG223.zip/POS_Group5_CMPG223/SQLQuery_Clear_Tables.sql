﻿delete from PURCHASE_ORDER_ITEM;
delete from SALES_ORDER_ITEM;
delete from PURCHASE_ORDER;
delete from SALES_ORDER;
delete from SUPPLIER;
delete from PRODUCT;